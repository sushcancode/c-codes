#include<iostream>
using namespace std;
int main()
{
    int n=5;
    int *p=&n;
    cout<<p;
    return 0;
}