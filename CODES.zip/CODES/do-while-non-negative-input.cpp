#include<iostream>
using namespace std;
int main()
{
    int n;
    do{
        cin>>n;
        cout<<n<<endl;
    }
    while(n>=0);
    return 0;
}
// while loop
#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    while(n>=0)
    {
        cout<<n<<endl;
        cin>>n;
    }
    return 0;
}
