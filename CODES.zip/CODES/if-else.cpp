#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Darling give an integer number"<<endl;
    cin>>n;
    if(n%2==0)
    {
        cout<<"Darling the input number is even"<<endl;
    }
    else
    {
        cout<<"Darling the input number is odd"<<endl;
    }
    return 0;
}