#include<iostream>
using namespace std;
int main()
{
cout<<"BACCHA BABY";
return 0;
}